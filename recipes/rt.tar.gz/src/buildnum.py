num = "3e32a66"
